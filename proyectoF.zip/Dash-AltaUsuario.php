<?php
session_start();

if(!isset($_SESSION['usuarioAdmin'])){

  header("Location:index.php");
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/style-estructura2.css">
    <title>Alta Usuario</title>
</head>
<body>
    <header class="bandaEncabezado">
        <div class="Encabezado">
            <div class="btn-menu">
                <label for="btn-menu">☰</label>
            </div>

            <div class="logo">
                <h1>ICABC</h1>
            </div>

           <nav class="menu">
                <a href="cerrarSesion.php">Cerrar Sesion</a>
            </nav>
        </div>
    </header>
    <input type="checkbox" id="btn-menu">
    <div class="container-menu">
        <div class="barraLateral">
           
            <nav>
                <a href="Dash-inicio.php">Inicio</a>
                <a href="Dash-AltaUsuario.php">Alta Usuario</a>
                <a href="Dash-Asig.php">Asignar Psicologo</a>
                <a href="Dash-ConsultUser.php">Consultar Usuarios</a>
                <a href="">Modificar Usuario</a>
                <a href="#">Baja Usuario</a>
            </nav>
            <label for="btn-menu">✖️</label>
        </div>
    </div>
    <div class="container-formularios">
        <div class="formulario">
            <center><br>
                <h1>Alta de usuarios</h1><br>
                <form name="altaU" action="phpAltaUsuarios.php" method="POST">
                   <input class="form-control" type="text" name="nombreUsuario" placeholder="Nombre de usuario" required><br>
                   <input class="form-control" type="password" name="claveUsuario" placeholder="Contraseña" required><br>
                   <input class="form-control" type="password" name="claveUsuario2" placeholder="Contraseña" required><br>
                   <select name="tiposUser" required><br>
                        <option selected disabled value="">Tipo de usuario</option>
                        <option value="Administrador">Administrador</option>
                        <option value="Doctor">Doctor</option>
                        <option value="Paciente">Paciente</option>
                    </select><br><br>
                    <input type="submit" value="Crear usuario">
                </form>
            </center>
        </div>
    </div>
</body>
</html>