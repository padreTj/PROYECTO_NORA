<?php
 session_start();

if(!isset($_SESSION['tipoUser']) && !isset($_SESSION['claveUser'])){

  header("Location:index.php");
}
 ?>
 <?php
// Verificamos la conexión con el servidor y la base de datos
  $mysqli = new mysqli('localhost', 'id18803800_proyectonora_362', 'ClaveNora362_', 'id18803800_databasenora');

$nombreU=$_SESSION['tipoUser'];

        

?>


<style>
    
    .caja{
        border: 5px outset red;
  background-color: lightblue;    
  
 height: 100px;
  width: 30%;
  
    }
</style>
 
<form name="preguForm" action="phpEnviarPregResu.php" method="POST">

<?php

$acum=0;
$nombreU=$_SESSION['tipoUser'];
$query = $mysqli -> query ("SELECT Preguntas.pregunta,Preguntas.idPregunta FROM Preguntas JOIN ".$nombreU."_Preguntas ON ".$nombreU."_Preguntas.idPregunta = Preguntas.idPregunta WHERE ".$nombreU."_Preguntas.bandera=1 ORDER BY Preguntas.idPregunta LIMIT 5");
 while ($valores = mysqli_fetch_array($query)) {
$acum++;
  $nume=$valores['idPregunta'];
  echo '<div id="nameDiv" class="caja">'.$nume.'.- '.$valores['pregunta'].'<br><input type="radio" id="si" name="res'.$acum.'" value="Si">
<label for="si">Si</label><br>
<input type="radio" id="no" name="res'.$acum.'" value="No">
<label for="no">No</label><br></div><br>
';
}

?>
<br>
<input type="submit" value="Enviar">

</form>
