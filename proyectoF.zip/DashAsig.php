<?php
session_start();

if(!isset($_SESSION['usuarioAdmin'])){

  header("Location:index.php");
}

?>
<!--inicio de sesion-->
<!doctype html>
<html lang="es">
<?php
// Verificamos la conexión con el servidor y la base de datos
  $mysqli = new mysqli('localhost', 'id18803800_proyectonora_362', 'ClaveNora362_', 'id18803800_databasenora');
?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.84.0">
    <title>Dashboard</title>





    <!-- Bootstrap core CSS -->
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./CSS/sidebars.css">
    <link rel="stylesheet" href="./CSS/bootstrap.min.css">

    <!-- Estilo personalizado para el sidebar -->
    <link href="./CSS/sidebars.css" rel="stylesheet">
    <link rel="stylesheet" href="CSS/newUsuario.css">

</head>

<body>
    <title>Altas MOD</title>
    <main>
        <div class="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark col-xxl-2 col-xl-3 col-lg-3 col-md-4 col-sm-5 col-5">
            <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                <img src="img/Logo3.svg" width="50" height="50" alt="">
                <!--Poner icono personalizado-->
                <span class="fs-4">Administrador</span>
            </a>
            <hr>
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="Dashboard.php" class="nav-link text-white" aria-current="page">
                        <svg class="bi me-2" width="16" height="16"><use xlink:href="#home"/></svg>Inicio
                    </a>
                </li>
                <li>
                    <a href="DashAlta.php" class="nav-link text-white">
                        <svg class="bi me-2" width="16" height="16"><use xlink:href="#speedometer2"/></svg>Alta Usuario
                    </a>
                </li>

                <li>
                    <a href="DashAsig.php" class="nav-link active">
                        <svg class="bi me-2" width="16" height="16"><use xlink:href="#speedometer2"/></svg>Asignar Psicologo
                    </a>
                </li>

 <li>
                    <a href="DashAsig.php" class="nav-link text-white">
                        <svg class="bi me-2" width="16" height="16"><use xlink:href="#speedometer2"/></svg>Consultar Usuarios
                    </a>
                </li>
                
                <li>
                    <a href="DashAsig.php" class="nav-link text-white">
                        <svg class="bi me-2" width="16" height="16"><use xlink:href="#speedometer2"/></svg>Modificar Usuario
                    </a>
                </li>



                <li>
                    <a href="DashBaja.php" class="nav-link text-white">
                        <svg class="bi me-2" width="16" height="16"><use xlink:href="#table"/></svg>Baja Usuario
                    </a>
                </li>

            </ul>
            <hr>

            <div class="dropdown">
            <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                <!--Logo-->
                <!--Dar valor de una etiqueta con el nombre de usuario-->
            </a>
            <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                <li><a class="dropdown-item" href="#">Configuración</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="cerrarSesion.php">Cerrar sesión</a></li>
            </ul>
            </div>
        </div>

        </div>
        <div class="b-example-divider col-xxl-10 col-xl-9 col-lg-9 col-md-8 col-sm-7 col-7">
            
        <div class="div_padre">
            
            
            <div class="div_hijo">
                
                    
  <div class="form-body">
    
    <div class="row">
      <div class="form-holder">
        <div class="form-content">
          <div class="form-items">
          <div class="imagen">
            <img src="./img/Logo3.svg" width="40%">

          </div>
          <h3>Asignar Psicologo</h3>
          <p>Llena los campos</p>

           <form name="asigPsi" action="phpAsigna.php" method="POST" class="requires-validation" novalidate>

            
            <div class="col-md-12">
              <select name="pac" class="form-select mt-3" required>
                <option selected disabled value="">Selecciona un paciente</option>
                
                
                <?php


$query = $mysqli -> query ("SELECT nombre,idUsuario FROM _Paciente ORDER BY idUsuario DESC");
 while ($valores = mysqli_fetch_array($query)) {

  echo '<option value="'.$valores[idUsuario].'">'.$valores[nombre].'</option>';
}


?>


              </select>
              <div class="valid-feedback">Paciente seleccionado</div>
              <div class="invalid-feedback">Porfavor seleccione un paciente</div>
            </div>

            


<div class="col-md-12">
              <select name="psi" class="form-select mt-3" required>
                <option selected disabled value="">Selecciona un psicologo</option>
                
            
<?php


$query = $mysqli -> query ("SELECT nombre,idUsuario FROM usuarios WHERE tipoUsuario='Doctor' ORDER BY idUsuario DESC");
 while ($valores = mysqli_fetch_array($query)) {

  echo '<option value="'.$valores[idUsuario].'">'.$valores[nombre].'</option>';
}


?>


              </select>
              <div class="valid-feedback">Psicologo seleccionado</div>
              <div class="invalid-feedback">Porfavor seleccione un psicologo</div>
            </div>







            <div class="form-check">
              <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
              <label class="form-check-label">Todos los datos son correctos?</label>
              <div class="invalid-feedback">Marca la casilla si ya verificaste que los datos sean correctos</div>
            </div>

            <div class="form-button mt-3">
              <button id="submit" type="submit" class="btn btn-primary">Asignar Psicologo</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

            </div>


        </div>
        
    
        </div>
        

        
    </main>


    
    <script src="./JS/newUsuario.js"> </script>
    <script src="./JS/bootstrap.bundle.min.js"></script>
    <script src="./JS/sidebars.js"></script>
</body>

</html>