<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/mygrid.css">
    <title>Nuevo</title>
</head>


    <body class = "grid-container">


    
        <nav class = "nav">

            <div class="nav-cont" id="menu">
                <div class="logo">
                    <img src="img/Logo3.svg" width="50" height="50" onclick="openNav()">
                </div>
                <h1 class = descripcion>Titulo</h1>

                </nav>

                <aside class = aside>
                    
                </aside>

                <main class = "main">

                </main>

                 <div id="mySidenav" class="sidenav">
                            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                            <a href="#">pagina1</a>
                            <a href="#">pagina2</a>
                            <a href="#">pagina3</a>
                            <a href="#">pagina4</a>
                </div> 

        <script src="JS/jquery.js"></script>
        <script src="JS/script.js"></script>
    </body>
   



</html>