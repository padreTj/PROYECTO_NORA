<?php
session_start();

if(!isset($_SESSION['usuarioAdmin'])){

  header("Location:index.php");
}

?>

<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.84.0">
    <title>Dashboard</title>





    <!-- Bootstrap core CSS -->
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./CSS/sidebars.css">
    <link rel="stylesheet" href="./CSS/bootstrap.min.css">

    <!-- Estilo personalizado para el sidebar -->
    <link href="./CSS/sidebars.css" rel="stylesheet">

</head>

<body>
    <title>Administrador</title>
    <main>
        <div class="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark col-xxl-2 col-xl-3 col-lg-3 col-md-4 col-sm-5 col-12">
            <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                <img src="img/Logo3.svg" width="50" height="50" alt="">
                <!--Poner icono personalizado-->
                <span class="fs-4">Administrador</span>
            </a>
            <hr>
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="Dashboard.php" class="nav-link active" aria-current="page">
                        <svg class="bi me-2" width="16" height="16"><use xlink:href="#home"/></svg>Inicio
                    </a>
                </li>
                <li>
                    <a href="DashAlta.php" class="nav-link text-white">
                        <svg class="bi me-2" width="16" height="16"><use xlink:href="#speedometer2"/></svg>Alta Usuario
                    </a>
                </li>


                <li>
                    <a href="DashAsig.php" class="nav-link text-white">
                        <svg class="bi me-2" width="16" height="16"><use xlink:href="#speedometer2"/></svg>Asignar Psicologo
                    </a>
                </li>

                <li>
                    <a href="DashAsig.php" class="nav-link text-white">
                        <svg class="bi me-2" width="16" height="16"><use xlink:href="#speedometer2"/></svg>Consultar Usuarios
                    </a>
                </li>
                
                <li>
                    <a href="DashAsig.php" class="nav-link text-white">
                        <svg class="bi me-2" width="16" height="16"><use xlink:href="#speedometer2"/></svg>Modificar Usuario
                    </a>
                </li>


                <li>
                    <a href="DashBaja.php" class="nav-link text-white">
                        <svg class="bi me-2" width="16" height="16"><use xlink:href="#table"/></svg>Baja Usuario
                    </a>
                </li>
            

            </ul>
            <hr>

        <div class="dropdown">
            <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                <!--Logo-->
                <!--Dar valor de una etiqueta con el nombre de usuario-->
            </a>
            <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                <li><a class="dropdown-item" href="#">Configuración</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="cerrarSesion.php">Cerrar sesión</a></li>
            </ul>
            </div>
        </div>
                
        </div>
        <div class="b-example-divider col-xxl-10 col-xl-9 col-lg-9 col-md-8 col-sm-6 col-0">
            <img src="img/Logo3.svg" width="70%" heigth="50%" alt="">
        </div>
        <div>

        </div>

    </main>



    <script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./JS/bootstrap.bundle.min.js"></script>
    <script src="./JS/sidebars.js"></script>
</body>

</html>