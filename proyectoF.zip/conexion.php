<?php

$cons_usuario="id18803800_proyectonora_362";
$cons_contra="ClaveNora362_";
$cons_base_datos="id18803800_databasenora";
$cons_equipo="localhost";

$obj_conexion = mysqli_connect($cons_equipo,$cons_usuario,$cons_contra,$cons_base_datos);
?>