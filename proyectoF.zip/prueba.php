<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* {
  box-sizing: border-box;
}


[class*="col-"] {
  float: left;
  padding: 5px;
}


.col-3 {
width: 20%;
height:100vh;

background-color: #212529;
}

.col-9 {
width: 80%;
height:200px;
background-color:red;
}


html {
  font-family: "Lucida Sans", sans-serif;
}



.menu ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
}

.menu li {
  padding: 8px;
  margin-bottom: 7px;
  background-color: #33b5e5;
  color: #ffffff;
  box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
}

.menu li:hover {
  background-color: #0099cc;
}
</style>
</head>
<body>





  <div class="col-3 menu">
      <center>
          <img src="img/Logo3.svg" width="80px" height="80px">
      </center>
      
    <ul>
      <li>Inicio</li>
      <li>Alta Usuario</li>
      <li>Asignar Psicologo</li>
      <li>Consultar Usuario</li>
      <li>Modificar Usuario</li>
      <li>Eliminar Usuario</li>
      
      
    </ul>
  </div>

  <div class="col-9">
      
      <h3>Registro de Usuario</h3>
          <p>Ingresa los datos del usuario</p>

          <form name="altaU" action="phpAltaUsuarios.php" method="POST" class="requires-validation" novalidate>

           
              <input class="form-control" type="text" name="nombreUsuario" placeholder="Nombre de usuario" required>
              

            <br>

              <input class="form-control" type="password" name="claveUsuario" placeholder="Contraseña" required>
          
           <br>

           
              <input class="form-control" type="password" name="claveUsuario2" placeholder="Contraseña" required>
       
          <br>

            
           
              <select name="tiposUser" class="form-select mt-3" required>
                <option selected disabled value="">Tipo de usuario</option>
                <option value="Administrador">Administrador</option>
                <option value="Doctor">Doctor</option>
                <option value="Paciente">Paciente</option>
              </select>
         <br>

            

              <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
              <label class="form-check-label">Todos los datos son correctos?</label>
             
          <br>

            <div class="form-button mt-3">
              <button id="submit" type="submit" class="btn btn-primary">Crear Usuario</button>
            </div>
          </form>
      
  
    
  </div>


</body>
</html>