
            <center><br>
             <table border="1">
                                <thead>
                                    <tr>
                                        <th>idUsuario</th>
                                        <th>Nombre</th>
                                        <th>apellidoPaterno</th>
                                        <th>apellidoMaterno</th>
                                        <th>edad</th>
                                        <th>sexo</th>
                                        <th>Correo electronico</th>
                                    </tr>
                                </thead>
                                <?php
                                include("./conexion.php");
                                
                                
                       

  
                                $sql2="SELECT usuarios.idUsuario,datosPersonales.nombre,apellidoPaterno,apellidoMaterno,edad,sexo,correoE FROM datosPersonales JOIN medico_Paciente ON medico_Paciente.idPaciente=datosPersonales.idUsuario JOIN usuarios ON usuarios.idUsuario=datosPersonales.idUsuario WHERE idMedico=29 AND usuarios.nombre='paciente1'";
                                $ejecutar2=mysqli_query($obj_conexion, $sql2);
                                while($fila2=mysqli_fetch_array($ejecutar2)){
                                ?>
                                <tbody>
                                    <tr>
                                        <td><?php echo $fila2[0] ?></td>
                                        <td><?php echo $fila2[1] ?></td>
                                        <td><?php echo $fila2[2] ?></td>
                                        <td><?php echo $fila2[3] ?></td>
                                        <td><?php echo $fila2[4] ?></td>
                                        <td><?php echo $fila2[5] ?></td>
                                        <td><?php echo $fila2[6] ?></td>

                                    </tr>
                                </tbody>
                                <?php
                                }
                                ?>
                            </table>
                            <br>
                            <a href="doctorConsultUser.php">Volver</a>
               
            </center>
        </div>
    </div>
</body>
</html>