function openNav() {
    document.getElementById("mySidenav").style.width = "100%";
    document.getElementById("main").style.marginLeft = "0%";
  }
  
  function closeNav() {
    document.getElementById("mySidenav").style.width = "0%";
  }  

