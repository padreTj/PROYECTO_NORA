<?php
$servername = "localhost";
$username = "id18803800_proyectonora_362";
$password = "ClaveNora362_";
$dbname = "id18803800_databasenora";

$userName=htmlentities(addslashes($_POST["nombreUsuario"]));
$passWord=htmlentities(addslashes($_POST["claveUsuario"]));
$passWord2=htmlentities(addslashes($_POST["claveUsuario2"]));
$userType=htmlentities(addslashes($_POST["tiposUser"]));



// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


$sql = "INSERT INTO usuarios (nombre, clave, tipoUsuario)
VALUES ('".$userName."', '".$passWord."', '".$userType."')";




 $sql990 = "SELECT * FROM usuarios WHERE nombre='".$userName."'";
     $result600 = $conn->query($sql990);
    
    
    
     if ($result600->num_rows > 0) {
         
         echo "<script>
                alert('Ya existe un usuario con ese nombre');
                window.location= 'Dash-AltaUsuario.php'
               
            </script>";
         
         
     }else{
         
         
         
         if($passWord2==$passWord){

if ($conn->query($sql) === TRUE) {
    
    
    
     $sql55 = "SELECT idUsuario,tipoUsuario FROM usuarios ORDER BY idUsuario desc limit 1";
     $result55 = $conn->query($sql55);
    
    
    
     if ($result55->num_rows > 0) {
         
         $row = mysqli_fetch_array($result55, MYSQLI_ASSOC);
       $vari= $row["tipoUsuario"];
       $idUser= $row["idUsuario"];
       
       
       if($vari=="Paciente"){
           
           $sqlCrearTabla="CREATE TABLE ".$userName."_Preguntas (
    pregID int NOT NULL AUTO_INCREMENT,
    idPregunta int NOT NULL,
    idUsuario int NOT NULL,
    respuesta varchar(40) NULL,
    valor int NULL,
    bandera int NOT NULL,
    PRIMARY KEY (pregID),
    FOREIGN KEY (idPregunta) REFERENCES Preguntas(idPregunta),
    FOREIGN KEY (idUsuario) REFERENCES usuarios(idUsuario)
);";
           
           if ($conn->query($sqlCrearTabla) === TRUE) {
               
               
               
               for($i=1;$i<=80;$i++){
                     $sqlPreguntas = "INSERT INTO ".$userName."_Preguntas(idPregunta, idUsuario,bandera)
        VALUES (".$i.", '".$idUser."','1')";
        
        
        $conn->query($sqlPreguntas);
               
                   
                   
               }
               
              
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
               
                $sql56 = "SELECT idUsuario,nombre FROM usuarios ORDER BY idUsuario desc limit 1";
        $result56 = $conn->query($sql56);
        
        if ($result56->num_rows > 0) {
            
            
            $row2 = mysqli_fetch_array($result56, MYSQLI_ASSOC);
       $variId= $row2["idUsuario"];
       $variNombre= $row2["nombre"];
            
            
             $sql33 = "INSERT INTO _Paciente (idUsuario, nombre)
        VALUES (".$variId.", '".$variNombre."')";
            
            
            if ($conn->query($sql33) === TRUE) {
                
                   echo "<script>
        alert('Registro exitoso');
        window.location= 'Dash-AltaUsuario.php'
        </script>";
                
            }else{
                
            echo "<script>
                alert('Ocurrio un error inesperado');
                window.location= 'Dash-AltaUsuario.php'
               
            </script>";
        
                
            }
            
            
            
            
        }
        
               
           }
           
           
           
           
           
           
           
           
           
           
           
           
           
           
           
       
        
           
           
       }else{
               echo "<script>
        alert('Registro exitoso');
        window.location= 'Dash-AltaUsuario.php'
        </script>";
       }
      
         
         
         
     }
    
    
    
    
    
    
    


}



    
}else{

    echo "<script>
                alert('Las contraseñas no coinciden');
                window.location= 'Dash-AltaUsuario.php'
               
    </script>";


}
         
         

         
         
     }




$conn->close();

?>